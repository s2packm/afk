fx_version 'bodacious'
game 'gta5'
lua54 'yes'

escrow_ignore {
    'config.lua',
}

client_scripts {
	'config.lua',
	'cl_afk.lua',
}

ui_page "html/index.html"

files {
    'html/index.html',
    'html/index.js',
    'html/index.css',
    'html/img/logo.png'
}