ESX = nil

local isAFK = false
local blur = "MenuMGIn"
local display = false

Citizen.CreateThread(function()
    while ESX == nil do
        TriggerEvent("esx:getSharedObject", function(obj)
            ESX = obj
        end)
        Citizen.Wait(0)
    end
end)

RegisterNUICallback("exit", function(data)
    SetEntityVisible(PlayerPedId(), true, true)
    SetEntityInvincible(PlayerPedId(), false)
    SetEntityCollision(PlayerPedId(), true, true)
    FreezeEntityPosition(PlayerPedId(), false)
    SetDisplay(false)
    DisplayRadar(true)
    print("stop zAFK")
    StopScreenEffect(blur)
    isAFK = false
end)

RegisterCommand('afk', function(source, args)
    if isAFK == true then
        SetEntityVisible(PlayerPedId(), true, true)
        SetEntityInvincible(PlayerPedId(), false)
        SetEntityCollision(PlayerPedId(), true, true)
        FreezeEntityPosition(PlayerPedId(), false)
        SetDisplay(false)
        DisplayRadar(true)
        StopScreenEffect(blur)
        isAFK = false
        return
    end
    if isAFK == false then
        DisableControlAction(0,18,false)
        SetEntityVisible(PlayerPedId(), false, false)
        SetEntityInvincible(PlayerPedId(), true)
        SetEntityCollision(PlayerPedId(), false, false)
        FreezeEntityPosition(PlayerPedId(), true)
        SetDisplay(true)
        DisplayRadar(false)
        StartScreenEffect(blur, 1, true)
        isAFK = true
    end
end)

Citizen.CreateThread(function()
	while true do
		time = 350
		if isAFK == true then
			time = 0
            Citizen.Wait(Config.timer)
            exports.es_extended:money_Add(200)
            ESX.ShowNotification('Vous avez reçu ~b~200 Dollars~s~.')
		end
		Citizen.Wait(time)
	end
end) 

function SetDisplay(bool)
    display = bool
    Wait(100)
    SetNuiFocus(bool, bool)
    SendNUIMessage({
        type = "ui",
        status = bool,
    })
end