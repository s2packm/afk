Config = {}

Config.timer = 900000 -- 15 minutes